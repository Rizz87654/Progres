module.exports = {
  tokens: "8340954885:AAFdfsuU_4gUZRIsj4Zn2XTQM-N6iPWyeXc",
  owner: "8257490486",
  port: "1554",
  ipvps: "http://rezagantengboyy.privateeserverr.my.id"
};